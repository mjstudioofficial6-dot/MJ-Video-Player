package com.mjstudio.videoplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var videoView: ZoomTextureView
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private lateinit var speedLabel: TextView
    private val pickVideo = 1001
    private val speeds = listOf(0.05f, 0.1f, 0.25f, 0.5f, 1f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF101820.toInt()
        window.navigationBarColor = 0xFF101820.toInt()
        buildUi()
        initializePlayer()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFF101820.toInt())
        }

        val heading = TextView(this).apply {
            text = "MJ VIDEO PLAYER"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, -2))

        videoView = ZoomTextureView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
        }
        root.addView(videoView, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Gallery se video select karein"
            textSize = 13f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        val playbackRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        playButton = makeButton("Play") { togglePlayback() }
        playbackRow.addView(playButton, weightedButton())
        playbackRow.addView(makeButton("Change Video") { openGallery() }, weightedButton())
        root.addView(playbackRow)

        speedLabel = TextView(this).apply {
            text = "Playback speed: 1.00×"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        }
        root.addView(speedLabel)

        val slowRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        listOf("0.05×", "0.1×", "0.25×", "0.5×", "1×").forEachIndexed { index, label ->
            slowRow.addView(makeButton(label) { applySpeed(speeds[index]) }, weightedButton())
        }
        root.addView(slowRow)

        root.addView(makeButton("Custom Speed") { showCustomSpeed() },
            LinearLayout.LayoutParams(-1, -2))

        val zoomInfo = TextView(this).apply {
            text = "Pinch Zoom: 1×–300×  •  Drag: Pan  •  Select a new video to reset"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 8, 0, 2)
        }
        root.addView(zoomInfo)
        setContentView(root)
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, -2, 1f).apply {
        setMargins(2, 4, 2, 4)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0
            setOnClickListener { action() }
        }

    private fun initializePlayer() {
        player = ExoPlayer.Builder(this).build().also { exo ->
            exo.setVideoTextureView(videoView)
            exo.addListener(object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playButton.text = if (isPlaying) "Pause" else "Play"
                }
            })
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            player?.setMediaItem(MediaItem.fromUri(uri))
            player?.prepare()
            player?.playWhenReady = true
            videoView.resetZoom()
            status.text = "Video loaded"
        }
    }

    private fun togglePlayback() {
        val currentPlayer = player ?: return
        if (currentPlayer.isPlaying) currentPlayer.pause() else currentPlayer.play()
    }

    private fun showCustomSpeed() {
        val edit = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("1.0")
            hint = "0.05 to 2.0"
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Custom playback speed")
            .setView(edit)
            .setPositiveButton("Apply") { _, _ ->
                val value = edit.text.toString().toFloatOrNull()
                if (value == null || value < 0.05f || value > 2f) {
                    Toast.makeText(this, "Speed 0.05× se 2× ke beech honi chahiye", Toast.LENGTH_LONG).show()
                } else {
                    applySpeed(value)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun applySpeed(speed: Float) {
        player?.playbackParameters = PlaybackParameters(speed)
        speedLabel.text = "Playback speed: ${"%.2f".format(speed)}×"
    }

    override fun onStart() {
        super.onStart()
        if (player == null) initializePlayer()
    }

    override fun onStop() {
        player?.release()
        player = null
        super.onStop()
    }
}

private class ZoomTextureView(context: android.content.Context) : TextureView(context) {
    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val oldZoom = zoom
                zoom = (zoom * detector.scaleFactor).coerceIn(1f, 300f)
                val factor = zoom / oldZoom
                offsetX = detector.focusX - (detector.focusX - offsetX) * factor
                offsetY = detector.focusY - (detector.focusY - offsetY) * factor
                applyTransform()
                return true
            }
        })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                dragging = true
            }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress && dragging && zoom > 1f) {
                offsetX += event.x - lastX
                offsetY += event.y - lastY
                applyTransform()
                lastX = event.x
                lastY = event.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    fun resetZoom() {
        zoom = 1f
        offsetX = 0f
        offsetY = 0f
        applyTransform()
    }

    private fun applyTransform() {
        val matrix = Matrix()
        matrix.setScale(zoom, zoom, width / 2f, height / 2f)
        matrix.postTranslate(offsetX, offsetY)
        setTransform(matrix)
        invalidate()
    }
}
