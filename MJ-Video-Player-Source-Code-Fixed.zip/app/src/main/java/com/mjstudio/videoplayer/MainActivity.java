package com.mjstudio.videoplayer;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int PICK_VIDEO = 4101;
    private static final int BG = Color.rgb(12, 16, 28);
    private static final int PANEL = Color.rgb(27, 34, 52);
    private static final int ACCENT = Color.rgb(102, 137, 255);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(165, 176, 198);
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView fileName, playPause;
    private Button slowButton;
    private final List<Uri> queue = new ArrayList<>();
    private int currentIndex = 0;
    private float speed = 1.0f;

    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        buildUi();
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                playPause.setText(isPlaying ? "Ⅱ" : "▶");
            }
            @Override public void onMediaItemTransition(@Nullable MediaItem item, int reason) {
                currentIndex = player.getCurrentMediaItemIndex();
                updateName();
            }
        });
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(12));
        root.setBackgroundColor(BG);

        TextView title = label("MJ VIDEO PLAYER", 21, WHITE, true);
        root.addView(title);
        TextView subtitle = label("Play videos directly from your phone", 12, MUTED, false);
        LinearLayout.LayoutParams sub = params(-1, -2); sub.topMargin = dp(4); root.addView(subtitle, sub);

        Button choose = makeButton("OPEN VIDEO", ACCENT, WHITE);
        LinearLayout.LayoutParams chooseP = params(-1, dp(42)); chooseP.topMargin = dp(16); root.addView(choose, chooseP);
        choose.setOnClickListener(v -> openPicker());

        playerView = new PlayerView(this);
        playerView.setBackground(round(Color.BLACK, 14));
        playerView.setClipToOutline(true);
        LinearLayout.LayoutParams videoP = new LinearLayout.LayoutParams(-1, 0, 1f);
        videoP.topMargin = dp(14); videoP.bottomMargin = dp(12);
        root.addView(playerView, videoP);

        fileName = label("No video selected", 12, MUTED, false);
        fileName.setMaxLines(1);
        root.addView(fileName);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams controlsP = params(-1, dp(48)); controlsP.topMargin = dp(8);
        root.addView(controls, controlsP);

        Button back = control("−10s"); controls.addView(back, params(dp(52), dp(40)));
        back.setOnClickListener(v -> { if (player != null) player.seekTo(Math.max(0, player.getCurrentPosition() - 10000)); });
        playPause = label("▶", 20, WHITE, true); playPause.setGravity(Gravity.CENTER);
        playPause.setBackground(round(PANEL, 12));
        LinearLayout.LayoutParams pp = params(dp(54), dp(40)); pp.setMargins(dp(8), 0, dp(8), 0); controls.addView(playPause, pp);
        playPause.setOnClickListener(v -> { if (player == null) return; if (player.isPlaying()) player.pause(); else player.play(); });
        Button forward = control("+10s"); controls.addView(forward, params(dp(52), dp(40)));
        forward.setOnClickListener(v -> { if (player != null) player.seekTo(player.getCurrentPosition() + 10000); });
        slowButton = makeButton("1.0×", PANEL, WHITE);
        LinearLayout.LayoutParams slowP = params(dp(66), dp(40)); slowP.leftMargin = dp(10); controls.addView(slowButton, slowP);
        slowButton.setOnClickListener(v -> cycleSpeed());

        TextView hint = label("10 sec back / forward     •     Slow motion", 10, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintP = params(-1, dp(22)); hintP.topMargin = dp(4); root.addView(hint, hintP);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                Insets systemInsets = windowInsets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(
                        dp(16) + systemInsets.left,
                        dp(16) + systemInsets.top,
                        dp(16) + systemInsets.right,
                        dp(12) + systemInsets.bottom);
                return windowInsets;
            });
        }
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 35) root.requestApplyInsets();
    }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_VIDEO); }
        catch (Exception e) { Toast.makeText(this, "File picker unavailable", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_VIDEO || resultCode != RESULT_OK || data == null) return;
        List<Uri> picked = new ArrayList<>();
        ClipData clips = data.getClipData();
        if (clips != null) {
            for (int i = 0; i < clips.getItemCount(); i++) picked.add(clips.getItemAt(i).getUri());
        } else if (data.getData() != null) picked.add(data.getData());
        if (picked.isEmpty()) return;
        queue.clear(); queue.addAll(picked); currentIndex = 0;
        int resultFlags = data.getFlags();
        int readGrant = resultFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        boolean canPersist = (resultFlags & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0;
        if (readGrant != 0 && canPersist) {
            for (Uri uri : picked) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, readGrant);
                } catch (SecurityException ignored) {
                    // Some document providers grant temporary read access only.
                }
            }
        }
        player.setMediaItems(toMediaItems(queue));
        player.prepare();
        speed = 1f; applySpeed();
        player.play();
        updateName();
    }

    private List<MediaItem> toMediaItems(List<Uri> uris) {
        List<MediaItem> items = new ArrayList<>();
        for (Uri uri : uris) items.add(MediaItem.fromUri(uri));
        return items;
    }
    private void updateName() {
        if (fileName == null || queue.isEmpty()) return;
        String name = queue.get(Math.min(currentIndex, queue.size()-1)).getLastPathSegment();
        fileName.setText((currentIndex + 1) + "/" + queue.size() + "  •  " + (name == null ? "Selected video" : name));
    }
    private void cycleSpeed() {
        float[] speeds = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
        int next = 0;
        for (int i = 0; i < speeds.length; i++) if (Math.abs(speed - speeds[i]) < 0.01f) next = (i + 1) % speeds.length;
        speed = speeds[next]; applySpeed();
    }
    private void applySpeed() {
        if (player != null) player.setPlaybackParameters(new PlaybackParameters(speed));
        if (slowButton != null) slowButton.setText(speed + "×");
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    private Button makeButton(String s, int bg, int fg) {
        Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(round(bg, 11)); b.setPadding(dp(5), 0, dp(5), 0);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setStateListAnimator(null); return b;
    }
    private Button control(String s) { return makeButton(s, PANEL, WHITE); }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override protected void onPause() { super.onPause(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { if (playerView != null) playerView.setPlayer(null); if (player != null) player.release(); super.onDestroy(); }
}
