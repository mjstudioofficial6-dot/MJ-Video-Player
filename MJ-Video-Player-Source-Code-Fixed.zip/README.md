# MJ Video Player

Standalone Android offline video player. The app does **not** import, copy, or store video files. Use **OPEN VIDEO** to choose one or multiple videos from the phone's document picker; Android grants the app read access to the selected URI(s), and Media3 plays them directly from their original location.

## Playback controls
- Compact play/pause button
- 10-second rewind and forward
- Playback speed cycle: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x
- Multiple selected videos play in sequence
- No INTERNET permission and no bundled video assets

## GitHub setup: use the two supplied files together
1. Upload `MJ-Video-Player-Source-Code.zip` to the **root** of the GitHub repository. Do not extract it manually; the workflow does that automatically.
2. Upload the separate workflow file as `.github/workflows/build-apk.yml`.
3. In GitHub, open **Actions** and run **Build MJ Video Player APK**, or push either of the two files to trigger the workflow.

The workflow checks and extracts the Source Code ZIP into the repository root, generates and verifies the Gradle Wrapper, then builds the APK.

## Build baseline
- Ubuntu 24.04 GitHub Actions runner
- Eclipse Temurin JDK 17
- Gradle 9.6.0 with SHA-256 verification and generated official Wrapper
- Android Gradle Plugin 9.4.0
- Android API 36 / Build Tools 36.0.0

The workflow validates that INTERNET permission is absent and runs a 15-second Android 16 emulator startup smoke test. Download the APK from the workflow run's artifact named `MJ-Video-Player-APK-and-Gradle-Wrapper`.
