# MJ Video Player

## Build setup used by GitHub Actions
The workflow follows the original MJ Video Player workflow pattern:

1. JDK 17
2. Android SDK
3. Android SDK Platform API 36
4. Gradle 9.6.0
5. Generate and verify Gradle Wrapper 9.6.0
6. Build Debug APK
7. Launch and smoke-test on Android 16 (API 36) Emulator
8. Upload APK and generated Gradle Wrapper artifacts

The project uses Android Gradle Plugin 9.4.0, which is compatible with Gradle 9.6.0,
JDK 17 and SDK Build Tools 36.0.0.

## App features
- Choose video from the phone's system video picker.
- Play / pause and change video.
- Playback speed buttons: 0.05×, 0.1×, 0.25×, 0.5× and 1×.
- Custom playback speed from 0.05× to 2×.
- Pinch zoom from 1× to 300× and drag to pan.

## Output
`app/build/outputs/apk/debug/app-debug.apk`
