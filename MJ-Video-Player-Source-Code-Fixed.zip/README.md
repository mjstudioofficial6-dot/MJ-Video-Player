# MJ Video Player

Native Android video player for videos already stored on the phone.

## Features

- Select one or multiple videos through Android's system document picker.
- Play the original selected content URIs directly with AndroidX Media3; the app does not copy videos into its private storage.
- Multiple selected videos play sequentially.
- Compact controls: 10-second back, play/pause, 10-second forward, and speed cycle (0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x).
- No `INTERNET` permission and no broad storage permission.
- Android 15/16 edge-to-edge system-bar and display-cutout insets are handled for the API 36 target.

For genuinely offline use, select video files that are downloaded and stored locally on the phone. Access to cloud-backed document providers may require network access outside this app.

## Verified build configuration

- GitHub Actions runner: `ubuntu-24.04`
- JDK: Eclipse Temurin 17
- Android Gradle Plugin: `9.4.0`
- Gradle Wrapper: `9.6.0` with the official distribution SHA-256 pinned
- Android SDK: `compileSdk 36`, `targetSdk 36`, Build Tools `36.0.0`
- AndroidX Annotation: `1.10.0` (stable)
- AndroidX Media3: `1.11.1` (stable)

The project ZIP includes the standard Gradle Wrapper scripts, JAR, and properties file. CI checks the Wrapper JAR and pinned Gradle distribution checksums, builds the debug APK, checks the package/activity and absence of Internet permission, then launches the APK on an Android 16 (API 36) emulator for a startup smoke test.
