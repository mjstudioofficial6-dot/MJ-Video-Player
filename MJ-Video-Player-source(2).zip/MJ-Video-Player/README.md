# MJ Video Player

Android video player starter project.

## Features
- Select a video from the phone using Android's document picker (`video/*`).
- Play and pause.
- Playback speeds: 0.05×, 0.1×, 0.25×, 0.5× and 1×.
- Custom playback speed from 0.05× to 2×.
- Pinch zoom (1×–300×), drag to pan, reset by selecting a new video.

## Build
Run `./gradlew assembleDebug`. The APK is created at:
`app/build/outputs/apk/debug/app-debug.apk`

The GitHub Actions workflow supplied separately extracts this source ZIP and builds the APK.
